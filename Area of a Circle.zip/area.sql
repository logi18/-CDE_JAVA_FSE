declare
radius number(5);
area number(7,2);
pi constant number (4,2):=3.14;
begin
radius:=3;
while radius<=7
 loop
 area := pi*power(radius,2);
 insert into circle values (radius,area);
 radius:=radius+1;
 end loop;
end;
/