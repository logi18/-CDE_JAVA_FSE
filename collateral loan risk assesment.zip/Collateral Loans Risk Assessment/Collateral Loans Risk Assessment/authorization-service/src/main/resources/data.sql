insert into user(id, name, password) values (1, 'naima', 'naima');
insert into user(id, name, password) values (2, 'priya', 'logapriya');





insert into customer(id,name,password) values (100011,'yasmeen ','yasmeen');
insert into customer(id,name,password) values (100012,'logapriya ','priya');
