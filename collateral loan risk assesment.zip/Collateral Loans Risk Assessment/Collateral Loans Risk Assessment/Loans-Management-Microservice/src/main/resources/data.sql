insert into customer(customer_id, customer_name, customer_email_id, customer_phone_no, customer_address) values(100001,'Syed Haseena','haseenasyed@gmail.com','7365907119','Kolkata');
insert into customer(customer_id, customer_name, customer_email_id, customer_phone_no, customer_address) values(100002,'Lalitha Jasti','lalithajasti@gmail.com','9874561231','Siliguri');
insert into customer(customer_id, customer_name, customer_email_id, customer_phone_no, customer_address) values(100003,'Rehana Shaik','rehanas@gmail.com','4567891232','Darjeeling');
insert into customer(customer_id, customer_name, customer_email_id, customer_phone_no, customer_address) values(100004,'Sravani','sravani12@gmail.com','1569891232','Hyderabad');
insert into customer(customer_id, customer_name, customer_email_id, customer_phone_no, customer_address) values(100005,'Lavanya','lavanya90@gmail.com','3698891232','Bhubaneswaar');
insert into customer(customer_id, customer_name, customer_email_id, customer_phone_no, customer_address) values(100006,'Prathyusha','prathyusha@gmail.com','6985891232','Banglore');
insert into customer(customer_id, customer_name, customer_email_id, customer_phone_no, customer_address) values(100007,'Rajeswari','rajeswari@gmail.com','4567891232','Darjeeling');
insert into customer(customer_id, customer_name, customer_email_id, customer_phone_no, customer_address) values(100008,'Srujana','srujana67@gmail.com','4567891232','Darjeeling');

 

 

 


insert into loan(loan_product_id,loan_product_name,max_loan_eligible,interest_rate,tenure,collateral_type) values(1001,'Home Loan',1500000,12.5,36,'REAL_ESTATE');
insert into loan(loan_product_id,loan_product_name,max_loan_eligible,interest_rate,tenure,collateral_type) values(1002,'Home Loan',1000000,13.5,30,'CASH_DEPOSIT');
insert into loan(loan_product_id,loan_product_name,max_loan_eligible,interest_rate,tenure,collateral_type) values(1003,'Car Loan',700000,11.5,30,'REAL_ESTATE');
insert into loan(loan_product_id,loan_product_name,max_loan_eligible,interest_rate,tenure,collateral_type) values(1004,'Car Loan',500000,12,24,'CASH_DEPOSIT');
insert into loan(loan_product_id,loan_product_name,max_loan_eligible,interest_rate,tenure,collateral_type) values(1005,'Education Loan',500000,12,24,'CASH_DEPOSIT');
insert into loan(loan_product_id,loan_product_name,max_loan_eligible,interest_rate,tenure,collateral_type) values(1006,'Medical Loan',500000,12,24,'REAL_ESTATE');
insert into loan(loan_product_id,loan_product_name,max_loan_eligible,interest_rate,tenure,collateral_type) values(1007,'Home Loan',500000,12,24,'CASH_DEPOSIT');
insert into loan(loan_product_id,loan_product_name,max_loan_eligible,interest_rate,tenure,collateral_type) values(1008,'Medical Loan',500000,12,24,'CASH_DEPOSIT');

 

 

 


