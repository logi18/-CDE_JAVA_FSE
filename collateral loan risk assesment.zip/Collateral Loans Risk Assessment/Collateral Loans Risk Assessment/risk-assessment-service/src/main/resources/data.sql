insert into collateralmarketvalue(rate_id,rate_per_sqr_feet)values(1,3000);

insert into collateralinterestrate(interest_id,interest_rate)values(1,12.5);


