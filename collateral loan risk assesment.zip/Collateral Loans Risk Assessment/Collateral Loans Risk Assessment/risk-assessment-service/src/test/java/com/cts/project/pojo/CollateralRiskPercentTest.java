package com.cts.project.pojo;

import org.junit.Test;
import org.meanbean.test.BeanTester;

/**
 * Test - CollateralRiskPercent class
 */
public class CollateralRiskPercentTest {

	@Test
	public void testPojoCollateralRiskPercent() {
		final BeanTester beanTester = new BeanTester();
		beanTester.testBean(CollateralRiskPercent.class);
	}

}
