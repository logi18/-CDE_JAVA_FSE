//WRITE YOUR JQUERY CODE HERE
$("#signup").click(function() {
 $("#signup_div").toggle();
 });
 