select concat(address, ', ', city) as address
from student
order by concat(address, city) desc;