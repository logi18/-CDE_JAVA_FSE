$('#msg').html("jQuery is loaded!!!");
