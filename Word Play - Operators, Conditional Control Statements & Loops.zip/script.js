function wordPlay(number){
    //fill the code
    var s = "";
        if(number<50){
            if(number>1){
            for(var i=1;i<=number;i++){
                s += " ";
                if (i%5===0){
                    s += "Clap";
                }
                else if(i%3===0){
                    s += "Tap"
                }
                else if (i%3===0 && i%5===0){
                    s += "Jump";
                }
                else{
                    s += i;
                }
            }
        }
            else{
                s = "Not Valid";
            }
        }
        else{
        s = "Range is High";
        }
    return s;
    
}
console.log(wordPlay(16));
console.log(wordPlay(-16));
console.log(wordPlay(166))