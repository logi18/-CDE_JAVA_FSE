function modifyString(str)
{
//fill code here
var res = str.replace(/\s+/g, "")
str = res.toLowerCase();
return str;
}

function uniqueCharacters(str)
{
//fill code here
str = modifyString(str);
 var uniq = "";
   
  for(var i = 0; i < str.length; i++){
    if(uniq.includes(str[i]) === false){
      uniq += str[i]
    }
  }
  return uniq;


}  
console.log(uniqueCharacters("Welcome to the Javascript course"))