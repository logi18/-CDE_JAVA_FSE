function validateEmail(email) {
   //fill the code
   var s = "";
   var mailformat = /^\w+([\.-]?\w+)@\w+([\.-]?\w+)(\.\w{2,3})+$/;
if(email.match(mailformat))
{
  s="Valid email address!";
}
else
{
  s="Invalid email address!";
}
return s;
}
console.log(validateEmail('info123@example.com'));
console.log(validateEmail('abc-defmail.com'));