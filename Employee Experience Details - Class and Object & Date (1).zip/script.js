// class Employee 
// {
// //fill code here
// }

// function createEmployee(name, designation, year_of_experience)
// {
// //fill code here
// }

// function validateObject(employee)
// {
// //fill code here
// }
function Emp(name, designation, year_of_experience){
    this.name = name;
    this.designation = designation;
    this.year_of_experience = year_of_experience;
}


function createEmployee(name, designation, year_of_experience)
{
//fill code here
var employee = new Emp(name, designation, year_of_experience);
return employee;
}

function validateObject(employee)
{
//fill code here
    if (employee instanceof Object=== true){
        var years_of_service = 2020 - employee.year_of_experience;
    }
    return years_of_service;
}
function displayEmployee(name, designation, year_of_experience){
    employee = createEmployee(name, designation, year_of_experience);
    years_of_service = validateObject(employee);
    var s = employee.name +" is serving the position of "+ employee.designation +" since "+years_of_service ;
    return s;
}
console.log(displayEmployee("Jerold","Manager",15));